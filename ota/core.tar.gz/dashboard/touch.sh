#!/bin/sh
# Đọc cảm ứng + nút nguồn cho Kindle Dashboard.
#   sh touch.sh          theo dõi: mỗi lần chạm -> ghi "x y" vào /tmp/dash_taps và đánh thức dash.sh;
#                        bấm nút nguồn -> về giao diện Kindle
#   sh touch.sh --probe  dò cảm ứng 25 giây, ghi log để hiệu chỉnh toạ độ
# Mỗi sự kiện input là 16 byte (ARM 32-bit): sec usec type code value.
DIR="$(cd "$(dirname "$0")" && pwd)"
. "$DIR/dash.conf"
[ -f "$DIR/settings.conf" ] && . "$DIR/settings.conf"
. "$DIR/lib/fw.sh"
FB=/tmp/dash_fbink
BOLD="$DIR/fonts/NotoSans-Bold.ttf"
: "${TOUCH_MAX_X:=758}" "${TOUCH_MAX_Y:=1024}" "${TOUCH_SWAP_XY:=0}" "${TOUCH_FLIP_X:=0}" "${TOUCH_FLIP_Y:=0}"

log() { echo "$(date '+%F %T') [touch] $*"; }

# Đọc một lượt: một lần read() lấy TẤT CẢ sự kiện đang chờ (tối đa 64), mỗi sự kiện một dòng
# "sec usec type|code value". Vuốt sinh hàng trăm sự kiện -> trước đây hàng trăm lần dd+od, nay chỉ vài lần.
ODV=""; echo | od -v -An -tu4 >/dev/null 2>&1 && ODV="-v"
if echo | od -An -tu4 >/dev/null 2>&1; then
  read_ev() { dd if="$1" bs=1024 count=1 2>/dev/null | od $ODV -An -tu4; }
else
  read_ev() { dd if="$1" bs=1024 count=1 2>/dev/null | hexdump -v -e '4/4 "%u " "\n"'; }
fi

devices() {
  for e in /dev/input/event*; do
    n=$(cat "/sys/class/input/$(basename "$e")/device/name" 2>/dev/null)
    echo "$e|$n"
  done
}

go_home() {
  # dashboard đã chết mà giao diện còn đóng băng -> vẫn phải đánh thức nó
  [ -f /tmp/dash.pid ] || fw_paused || { log "ignore $1: dashboard not running"; exit 0; }
  log "go home ($1)"
  touch /tmp/dash_stop
  msg="Đang về Home…"; fw_paused || msg="Đang về Home… (chờ khoảng 30 giây)"
  "$FB" -q -c -m -M -t "regular=$BOLD,px=44" "$msg" >/dev/null 2>&1
  pkill -f "$DIR/dash.sh" 2>/dev/null
  rm -f /tmp/dash.pid
  lipc-set-prop com.lab126.powerd preventScreenSaver 0 2>/dev/null
  fw_resume
  # trả khoá xoay về như lúc bắt đầu, khi giao diện Kindle đã chạy lại
  o=$(cat /tmp/dash_lock_orig 2>/dev/null); [ -n "$o" ] || o=U
  ( i=0; while [ $i -lt 120 ]; do
      if [ -n "$(lipc-get-prop com.lab126.winmgr orientationLock 2>/dev/null)" ]; then
        sleep 2; lipc-set-prop com.lab126.winmgr orientationLock "$o" 2>/dev/null; exit 0; fi
      sleep 1; i=$((i + 1)); done ) >/dev/null 2>&1 &
  pkill -f "dd if=/dev/input" 2>/dev/null
  pkill -f "$DIR/touch.sh" 2>/dev/null
  exit 0
}

# Nút nguồn: bình thường = về Home; nếu vừa dùng để đánh thức máy khỏi ngủ sâu thì chỉ đánh thức dashboard
power_key() {
  w=$(cat /tmp/dash_woke 2>/dev/null || echo 0)
  if [ -f /tmp/dash_sleeping ] || [ $(( $(date +%s) - w )) -lt 20 ]; then
    log "power: đánh thức khỏi ngủ sâu"
    kill -USR1 "$(cat /tmp/dash.pid 2>/dev/null)" 2>/dev/null
    return 0
  fi
  go_home "power button"
}

# Toạ độ cảm ứng -> toạ độ màn hình (758x1024)
map_xy() {
  x=$1; y=$2
  [ "$TOUCH_SWAP_XY" = 1 ] && { t=$x; x=$y; y=$t; }
  x=$(( x * 758 / TOUCH_MAX_X )); y=$(( y * 1024 / TOUCH_MAX_Y ))
  [ "$TOUCH_FLIP_X" = 1 ] && x=$(( 757 - x ))
  [ "$TOUCH_FLIP_Y" = 1 ] && y=$(( 1023 - y ))
  SX=$x; SY=$y
}

# $1=device  $2=mode(watch|probe)
watch_dev() {
  dev=$1; mode=$2
  X=-1; Y=-1; X0=-1; Y0=-1; down=0; last=0
  while :; do
    [ "$mode" = watch ] && [ -f /tmp/dash_stop ] && exit 0
    evs=$(read_ev "$dev")
    [ "$mode" = watch ] && { [ -f /tmp/dash_stop ] || [ ! -f /tmp/dash.pid ]; } && exit 0
    [ -n "$evs" ] || { sleep 1; continue; }
    while read -r e1 e2 e3 e4 e5; do
    set -- $e1 $e2 $e3 $e4 $e5
    [ $# -ge 5 ] && shift            # od có thể in thêm cột offset
    [ $# -lt 4 ] && continue
    w3=$3; val=$4
    type=$(( w3 % 65536 )); code=$(( w3 / 65536 ))
    [ "$val" -gt 2147483647 ] 2>/dev/null && val=$(( val - 4294967296 ))
    [ "$mode" = probe ] && [ "$type" != 0 ] && log "raw $dev type=$type code=$code value=$val"
    release=0
    case "$type" in
      3) case "$code" in
           0|53) X=$val; [ $X0 -lt 0 ] && X0=$val; down=1 ;;
           1|54) Y=$val; [ $Y0 -lt 0 ] && Y0=$val; down=1 ;;
           57) [ "$val" = -1 ] && release=1 ;;
         esac ;;
      1) case "$code" in
           330) [ "$val" = 0 ] && release=1; [ "$val" = 1 ] && down=1 ;;
           116) [ "$val" = 1 ] && { [ "$mode" = probe ] && log "POWER pressed" || power_key; } ;;
         esac ;;
    esac
    if [ $release = 1 ] && [ $down = 1 ] && [ $X -ge 0 ] && [ $Y -ge 0 ]; then
      now=$(date +%s)
      dx=$(( X - X0 )); dy=$(( Y - Y0 )); [ $dx -lt 0 ] && dx=$(( -dx )); [ $dy -lt 0 ] && dy=$(( -dy ))
      if [ $X0 -ge 0 ] && [ $Y0 -ge 0 ] && { [ $dx -ge 160 ] || [ $dy -ge 160 ]; }; then
        map_xy $X0 $Y0; s0x=$SX; s0y=$SY; map_xy $X $Y
        log "swipe raw=($X0,$Y0)->($X,$Y) screen=($s0x,$s0y)->($SX,$SY)"
        if [ "$mode" = watch ]; then
          echo "S $s0x $s0y $SX $SY" >> /tmp/dash_taps
          kill -USR1 "$(cat /tmp/dash.pid 2>/dev/null)" 2>/dev/null
        fi
        last=$(date +%s)
      elif [ $(( now - last )) -ge 1 ]; then
        last=$now; map_xy $X $Y
        log "tap raw=($X,$Y) screen=($SX,$SY)"
        if [ "$mode" = watch ]; then
          echo "$SX $SY" >> /tmp/dash_taps
          kill -USR1 "$(cat /tmp/dash.pid 2>/dev/null)" 2>/dev/null
        fi
      fi
      down=0; X0=-1; Y0=-1
    fi
    done <<EOT
$evs
EOT
  done
}

if [ "$1" = "--probe" ]; then
  log "devices:"; devices
  log "reader: $(echo | od -An -tu4 >/dev/null 2>&1 && echo od || echo hexdump)"
  cp "$DIR/bin/fbink" "$FB" 2>/dev/null && chmod +x "$FB"
  stop framework 2>/dev/null || stop lab126_gui 2>/dev/null
  sleep 2
  "$FB" -q -c -t "regular=$BOLD,px=40,top=330,left=40,right=40" "DÒ CẢM ỨNG (25 giây)

Chạm lần lượt 4 góc:
trên-trái, trên-phải,
dưới-trái, dưới-phải.
Cuối cùng bấm nút nguồn 1 lần." >/dev/null 2>&1
  for c in "0 0" "0 718" "984 0" "984 718"; do set -- $c; "$FB" -q -B BLACK -k "top=$1,left=$2,width=40,height=40" >/dev/null 2>&1; done
  for d in /dev/input/event*; do watch_dev "$d" probe & done
  sleep 25
  pkill -f "dd if=/dev/input" 2>/dev/null; kill $(jobs -p) 2>/dev/null
  log "probe done"
  start framework 2>/dev/null || start lab126_gui 2>/dev/null
  exit 0
fi

# Chế độ theo dõi
log "watching: $(devices | tr '\n' ' ')"
for d in /dev/input/event*; do watch_dev "$d" watch & done
wait
